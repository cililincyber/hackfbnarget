######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Febry, Bima, Accil, Alfa           #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest, Zhum Bai Lee          #
######################################
z="
";FBz='v}  ';EBz='m}${';GBz='  ${';tz='n="╝';Oz='pu="';oz='═══"';iz='v="\';vz='_ban';Az='a="\';Yz='hi="';ez='t="\';wz='ner_';aBz='══> ';dBz=' <══';dz='m╔"';NBz='    ';TBz='p}ST';ABz=' "${';Iz='k="\';Gz='h="\';pz='j="$';UBz='ATUS';Lz='34;1';Nz='35;1';JBz='NAMA';BBz='m}╔═';gz='u="\';IBz='${p}';nz='q="$';Tz='37;1';Dz='m"';Sz='p="\';rz='o="╚';OBz='${v}';HBz='h}{ ';bBz='${o}';CBz='═╗╔═';cBz='${n}';Vz='[38;';VBz=' ${h';Bz='033[';qz='x="$';xz='_.sh';Cz='30;1';Mz='c="\';DBz='═══╗';Qz='[36;';LBz='AN $';Ez='m="\';WBz='}}  ';Pz='\033';sz='"';SBz='{ ${';Zz='[40;';Hz='32;1';fz='m╗"';YBz='}║"';jz='z="$';QBz='║   ';lz='════';uz='sh _';kz='{b}═';Fz='31;1';RBz='${h}';Kz='b="\';bz='r';cz='s="\';az='clea';ZBz='o}══';mz='═"';yz='echo';hz='m║"';Wz='p2="';Xz='[39;';MBz='{h}}';PBz='${m}';Uz='m1="';XBz=' ${m';Rz='1m"';Jz='33;1';KBz=' TEM';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Bz$Tz$Dz$z$Uz$Pz$Vz$Rz$z$Wz$Pz$Xz$Rz$z$Yz$Pz$Zz$Rz$z$az$bz$z$cz$Bz$Lz$dz$z$ez$Bz$Lz$fz$z$gz$Bz$Lz$hz$z$iz$Bz$Fz$hz$z$jz$kz$lz$lz$lz$lz$lz$mz$z$nz$kz$oz$z$pz$kz$lz$lz$mz$z$qz$kz$oz$z$rz$sz$z$tz$sz$z$az$bz$z$uz$vz$wz$xz$z$yz$ABz$BBz$lz$lz$lz$lz$lz$CBz$lz$lz$lz$DBz$sz$z$yz$ABz$EBz$FBz$GBz$HBz$IBz$JBz$KBz$LBz$MBz$NBz$OBz$PBz$QBz$RBz$SBz$TBz$UBz$VBz$WBz$XBz$YBz$z$yz$ABz$EBz$ZBz$lz$lz$lz$lz$aBz$bBz$cBz$dBz$lz$lz$lz$cBz$sz$z$yz" 