z="
";Ez='  <═';Cz='33[3';Fz='════';Az='echo';Bz=' "\0';Dz='3;1m';Gz='══>"';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Gz$z$Az" 
