z="
";Rz='PAM ';Hz='9;1m';Mz='[39;';Vz='IRM ';Ez='╔═══';Iz='[\03';Zz='[32;';Cz='33[3';Uz='ERIK';cz='m]"';Nz='1m]\';Gz='═╗"';Sz='SUCE';dz='╚═══';Xz='3[39';Fz='════';ez='═╝"';Yz=';1m[';Az='echo';az='1m√\';Kz=';1m√';Wz=' \03';Jz='3[32';Qz='m  S';Tz='SS T';Lz='\033';Pz='32;1';Oz='033[';Dz='4;1m';Bz=' "\0';bz='39;1';
eval "$Az$z$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Gz$z$Az$Bz$Cz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Lz$Zz$az$Oz$bz$cz$z$Az$Bz$Cz$Dz$dz$Fz$Fz$Fz$Fz$Fz$Fz$ez$z$Az$z$Az" 
