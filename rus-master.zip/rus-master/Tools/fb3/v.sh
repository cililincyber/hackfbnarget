######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";Fz='31;1';EBz='${p}';tz='o="╚';pz='═══"';Qz='[36;';yz='b}  ';ABz='  ╔═';Xz='[39;';Kz='b="\';Mz='c="\';Yz='hi="';PBz='═══╝';Lz='34;1';NBz='   "';GBz=' FAC';Az='a="\';Dz='m"';nz='q="$';QBz='  "';HBz='EBOO';qz='j="$';oz='{b}═';Pz='\033';Tz='37;1';ez='t="\';Iz='k="\';fz='m╗"';lz='════';Sz='p="\';Rz='1m"';xz=' "${';jz='z="$';IBz='K NA';Ez='m="\';vz='n="╝';OBz='  ╚═';KBz=' TEM';Hz='32;1';hz='m║"';cz='s="\';Cz='30;1';FBz='HACK';Vz='[38;';gz='u="\';Uz='m1="';Oz='pu="';Zz='[40;';mz='>"';Wz='p2="';sz='x="$';LBz='AN $';kz='{b}<';RBz='z}"';Gz='h="\';az='clea';BBz='═══╗';Nz='35;1';MBz='{b}║';dz='m╔"';JBz='RGET';DBz='  ║ ';iz='v="\';uz='"';Jz='33;1';bz='r';Bz='033[';wz='echo';CBz=' "';rz='═"';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Bz$Tz$Dz$z$Uz$Pz$Vz$Rz$z$Wz$Pz$Xz$Rz$z$Yz$Pz$Zz$Rz$z$az$bz$z$cz$Bz$Lz$dz$z$ez$Bz$Lz$fz$z$gz$Bz$Lz$hz$z$iz$Bz$Fz$hz$z$jz$kz$lz$lz$lz$lz$lz$lz$lz$lz$lz$mz$z$nz$oz$pz$z$qz$oz$lz$lz$rz$z$sz$oz$pz$z$tz$uz$z$vz$uz$z$az$bz$z$wz$xz$yz$ABz$lz$lz$lz$lz$lz$lz$BBz$CBz$z$wz$xz$yz$DBz$EBz$FBz$GBz$HBz$IBz$JBz$KBz$LBz$MBz$NBz$z$wz$xz$yz$OBz$lz$lz$lz$lz$lz$lz$PBz$QBz$z$wz$xz$RBz" 
